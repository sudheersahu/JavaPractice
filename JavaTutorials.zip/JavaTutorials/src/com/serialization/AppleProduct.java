package com.serialization;

import java.io.Serializable;

public class AppleProduct implements Serializable {

    private String thunderboltPort;

    private String lightiningPort;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    private static final long serialVersionUID = 1234567L;

    private String headPhonePort;


    public String getThunderboltPort() {
        return thunderboltPort;
    }

    public void setThunderboltPort(String thunderboltPort) {
        this.thunderboltPort = thunderboltPort;
    }

    public String getLightiningPort() {
        return lightiningPort;
    }

    public void setLightiningPort(String lightiningPort) {
        this.lightiningPort = lightiningPort;
    }

    public String getHeadPhonePort() {
        return headPhonePort;
    }

    public void setHeadPhonePort(String headPhonePort) {
        this.headPhonePort = headPhonePort;
    }
}
