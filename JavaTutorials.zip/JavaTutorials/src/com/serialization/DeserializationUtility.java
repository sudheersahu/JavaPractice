package com.serialization;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Base64;

public class DeserializationUtility {

    public static void main(String[] args) throws IOException,ClassNotFoundException {

        String serilaizedObj = "rO0ABXNyAB5jb20uc2VyaWFsaXphdGlvbi5BcHBsZVByb2R1Y3QAAAAAABLWhwIAA0wADWhlYWRQaG9uZVBvcnR0ABJMamF2YS9sYW5nL1N0cmluZztMAA5saWdodGluaW5nUG9ydHEAfgABTAAPdGh1bmRlcmJvbHRQb3J0cQB+AAF4cHQAEWhlYWRwaG9uZVBvcnQyMDIwdAARbGlnaHRuaW5nUG9ydDIwMjB0ABN0aHVuZGVyYm9sdFBvcnQyMDIw";
        System.out.println("Deserializing AppleProduct...");
        AppleProduct deserializedObj = (AppleProduct)deSerializeObjectFromString(serilaizedObj);
        System.out.println("Headphone port of AppleProduct:" + deserializedObj.getHeadPhonePort());
        System.out.println("Thunderbolt port of AppleProduct:" + deserializedObj.getThunderboltPort());
        System.out.println("LightningPort port of AppleProduct:" + deserializedObj.getLightiningPort());
    }

public static Object deSerializeObjectFromString(String s) throws IOException,ClassNotFoundException {
        byte[] data = Base64.getDecoder().decode(s);
    ByteArrayInputStream bais = new ByteArrayInputStream(data);
    ObjectInputStream oi = new ObjectInputStream(bais);
   Object o =  oi.readObject();
    oi.close();
    return o;
}

}
