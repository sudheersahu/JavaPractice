package com.Exception;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IllegalStateExceotion {

    public static void main(String[] args){
      List<Integer> intlist = new ArrayList<>();

      for(int i =0 ; i< intlist.size(); i++){
          intlist.add(i);
      }

        Iterator<Integer> integerIterator = intlist.iterator();

      try{
          integerIterator.remove();
      }catch(IllegalStateException e){
          e.printStackTrace();
          System.out.println("Illegal state");
      }
    }
}
