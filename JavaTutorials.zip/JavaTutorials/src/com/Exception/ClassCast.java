package com.Exception;

class Animal {

}

class Dog extends Animal{

}

class Lion extends Animal{

}

public class ClassCast {


    public static void  main(String[] args){

        try{
            Animal animal1 = new Dog();
            Dog bruno = (Dog)animal1;

            Animal animalTwo = new Lion(); // At runtime the instance is animal
            Dog tommy = (Dog) animalTwo;
        }catch(ClassCastException e){
          System.out.println("ClassCastException caught!");
        }

    }
}
