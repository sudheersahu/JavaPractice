package com.Exception;

import java.io.PrintWriter;
import java.io.StringWriter;

public class StackTraceToString {

    public static void main(String[] args){
        try{
            throw new NullPointerException();
        }catch(Exception e){
            StringWriter s = new StringWriter();
            PrintWriter pw = new PrintWriter(s);
            e.printStackTrace(pw);
            System.out.println(s.toString());
        }
    }
}
