package com.Exception;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileNotFound {

    public static void main(String[] args){

        BufferedReader reader =null;
        try{
           // reader = new BufferedReader(new FileReader(new File("/invalid/file/location")));
            Thread.sleep(-1212);

        }  catch(InterruptedException e){
            e.printStackTrace();
        }
    }
}
