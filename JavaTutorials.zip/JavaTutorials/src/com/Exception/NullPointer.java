package com.Exception;

public class NullPointer extends Throwable {

    public static void main(String[] arg){

        Person person = null;
        try{
            person.setPersonName("sdsad");
            person.getPersonName();
        }catch(NullPointerException e){
            e.printStackTrace();
        }

    }
}

class Person{

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    private String personName;


}
