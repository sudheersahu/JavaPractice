package com.reflectionutils;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ReflectionUtils {

    public static List<String>  getNullPropertiesList(Customer customer) throws Exception{
        PropertyDescriptor[] descriptor = Introspector.getBeanInfo(Customer.class,Object.class).getPropertyDescriptors();

        return Arrays.stream(descriptor).filter(predicateNull(customer)).map(PropertyDescriptor:: getName).collect(Collectors.toList());
    }

    private static Predicate<PropertyDescriptor> predicateNull(Customer customer){
       return pd ->{
           boolean result=false;
           try{
               Method method = pd.getReadMethod();
               result = (method != null && method.invoke(customer) == null);
           }catch(Exception e){
               System.out.println("error invoking getter method");
           }

           return result;
       };
    }

    public static void main(String[] args) throws  Exception{

        Customer customer = new Customer("sudheer",1 ,null,112L);

        List<String> stringList = getNullPropertiesList(customer);
        System.out.println("stringList "+stringList);
    }

}
