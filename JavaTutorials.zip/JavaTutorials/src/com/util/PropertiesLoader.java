package com.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesLoader {

    public static Properties loadProperties(String fileName) throws IOException {
        Properties config = new Properties();
        InputStream inputStream = PropertiesLoader.class.getResourceAsStream(fileName);
        config.load(inputStream);
        inputStream.close();
        return config;
    }
}
