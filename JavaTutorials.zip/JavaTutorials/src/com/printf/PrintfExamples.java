package com.printf;

import java.util.Locale;

public class PrintfExamples {

    public static void main(String[] args){
        printfNewLine();
        printfString();
        printfChar();
        printfNumber();

        printfBoolean();
    }

    private static void printfNewLine(){
        System.out.printf("fskflfs%nfsfksfj%nfjsfjs");
    }

    private static void printfString(){

        System.out.printf("'%s' %n", "sudheer");
        System.out.printf("'%S' %n", "sudheer");
        System.out.printf("'%13s' %n", "sudheer");
        System.out.printf("'%-10s' %n", "sudheer");
    }

    private static void printfChar(){
        System.out.printf("%c%n",'c');
        System.out.printf("%C%n",'c');
    }

    private static void printfNumber(){
        System.out.printf("%d %n", 100L);
        System.out.printf(Locale.US, "%,d %n", 10000);
        System.out.printf(Locale.ITALY, "%,d %n", 10000);
    }

    private static void printfBoolean(){
        System.out.printf("%b%n", null);
        System.out.printf("%B%n", false);
        System.out.printf("%B%n", 5.3);
        System.out.printf("%b%n", "random text");
    }
 }
