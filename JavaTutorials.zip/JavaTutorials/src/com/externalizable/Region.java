package com.externalizable;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Region extends Country implements Externalizable {

    private static final long serialVersionUID = 1L;

    private String climate;
    private double population;
    private Community community;


    public String getClimate() {
        return climate;
    }

    public void setClimate(String climate) {
        this.climate = climate;
    }

    public double getPopulation() {
        return population;
    }

    public void setPopulation(double population) {
        this.population = population;
    }

    public Community getCommunity() {
        return community;
    }

    public void setCommunity(Community community) {
        this.community = community;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        super.writeExternal(out);
        out.writeDouble(population);
        out.writeUTF(climate);
        community =new Community();
        community.setId(5);
        out.writeObject(community);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        super.readExternal(in);
        this.climate = in.readUTF();
        this.community  = (Community)in.readObject();
    }

    @Override
    public String toString() {
        return "Region{" +
                "climate='" + climate + '\'' +
                ", population=" + population +
                ", community=" + community +
                '}';
    }
}
