package com.algorithmpractice;

public class Tester {
    public static void main(String[] args) {
        String s1 =new String("Hello");
        String s2 = new String("there");
        String s3 = new String();
        s3 = s1+s2;
        System.out.println(s3);
    }
}
