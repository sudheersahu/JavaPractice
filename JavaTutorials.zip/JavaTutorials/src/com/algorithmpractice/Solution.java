package com.algorithmpractice;

import java.util.HashMap;
import java.util.HashSet;

public class Solution {

    public static void main(String[] args){

        int[] array = {1, 3, 6, 4, 1, 2};
         int[] shiftedArray = shiftedArray(array, 3 );
        int smallest  = solutionsmallest(array);

        int[] tests = { 9, 37, 0b1000001010001 };
        for (int i : tests)
            System.out.printf("input = %d, Binary form = %s, Answer = %d%n",
                    i , Integer.toBinaryString(i), binaryGap(i));

        System.out.println(smallest);
        System.out.println(shiftedArray);

        int[] array1 = {9,3,9,3,9,7,9};
       int odd =  oddOccurenceInArray(array1);
        System.out.println(odd);
    }

    static int oddOccurenceInArray(int[] arr){
        HashMap<Integer,Integer> hp =new HashMap<>();

        for(int i =0; i< arr.length;i++){
            if(hp.containsKey(arr[i]) && hp.get(arr[i]) == 1){
                hp.remove(arr[i]);
            }else{
                hp.put(arr[i],1);
            }
        }

        for(int key : hp.keySet()){
            return key;
        }
       return 0;
    }

    static int binaryGap(int n) {
        return binaryGap(n, 0, 0);
    }

     public static int binaryGap(int n, int max, int current){
       if(n == 0 ){
           return max;
       }else if( n%2 == 0){
           return binaryGap(n/2, max, current +1);
       }else
           return binaryGap(n/2, Math.max(max,current),0);
      }

    public static int[] shiftedArray(int[] arr, int k){
        int[] shiftedArray = new int[arr.length];
     try{
         int pos = -1;
         if(arr.length ==1 ){
        return arr;
          }

          if(k> arr.length){
              k =k%arr.length;
          }

          for(int i =0 ; i< arr.length;i++){

              if( (i+k) > arr.length - 1){
                 pos = Math.abs(arr.length - i- k);
              }else{
                  pos = i+k;
              }
              shiftedArray[pos] = arr[i];
          }
          return  shiftedArray;
         }catch(Exception e){
         return  shiftedArray;
     }


    }

    public static int solutionsmallest(int[] a){
        int num =1;
        HashSet<Integer> hset =new HashSet<Integer>();

        for(int i=0; i<a.length; i++){
            hset.add(a[i]);

        }

        while(hset.contains(num)){
            num++;
        }
        return  num;
    }
}
