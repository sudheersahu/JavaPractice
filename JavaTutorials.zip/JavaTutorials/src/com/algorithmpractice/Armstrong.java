package com.algorithmpractice;

import java.util.Scanner;

public class Armstrong {

   static Scanner sc;

    public static void main(String[] args){
        sc = new Scanner(System.in);
        int n = inputInt("please enter the number");
        boolean isArmstrong = isArmstrong(n);
        if(isArmstrong){
            System.out.println("the number is armstrong");
        }else{
            System.out.println("the number is not armstrong");
        }
    }

    static boolean isArmstrong(int n){

        int temp =0,sum =0,remainder;
      temp = n;
      while(n>0){
          remainder =n%10;
          sum = sum + (remainder * remainder * remainder);
          n= n/10;
      }
        if (sum == temp) {
            return true;
        } else {
            return false;
        }

    }

    static int inputInt(String s){
        System.out.println(s);
        return Integer.parseInt(sc.nextLine());
    }
}
