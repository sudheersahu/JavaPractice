package com.stringpractice;

public class Student {
     public String getName(){
         return null;
     }

     public int getMarks(){
         return 10;
     }

}


