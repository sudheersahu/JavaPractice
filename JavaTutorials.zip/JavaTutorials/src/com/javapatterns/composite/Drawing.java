package com.javapatterns.composite;

import java.util.ArrayList;
import java.util.List;

public class Drawing implements Shape {

    private List<Shape> shapeList =new ArrayList<Shape>();

    @Override
    public void draw(String fillColor) {

        for(Shape shape : shapeList){
            shape.draw(fillColor);
        }
    }

    public void add(Shape s){
        shapeList.add(s);
    }

    public void remove(Shape s){
        shapeList.remove(s);
    }

    public void clearShapes(){
        System.out.println("Clearing all the shapes from drawing");
        this.shapeList.clear();
    }
}
