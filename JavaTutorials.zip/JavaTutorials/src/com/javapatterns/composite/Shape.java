package com.javapatterns.composite;

public interface Shape {

    public void draw(String fillColor);
}
