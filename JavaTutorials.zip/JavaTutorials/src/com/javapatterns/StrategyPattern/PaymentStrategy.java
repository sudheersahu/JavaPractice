package com.javapatterns.StrategyPattern;

public interface PaymentStrategy {

    void pay(int amount);
}
