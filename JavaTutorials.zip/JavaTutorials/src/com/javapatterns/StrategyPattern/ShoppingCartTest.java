package com.javapatterns.StrategyPattern;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCartTest {

    public static void main(String[] args){
        ShoppingCart cart = new ShoppingCart();
        Item item1 =new Item("1234",10);
        Item item2 = new Item("5678", 20);
        cart.addItem(item1);
        cart.addItem(item2);

        PaymentStrategy strategy = new CreditCardStrategy("sudheer","234","423432","12/15");
        cart.pay(strategy);
        cart.pay(new PaypalStrategy("fsdafa@sdf.com","32432"));

    }
}
