package com.javapatterns.StrategyPattern;

public class CreditCardStrategy implements PaymentStrategy {

    private String name;

    private String cvv;
    private String cardNumber;

    private String expiry;

    public CreditCardStrategy(String name, String cvv, String cardNumber, String expiry) {
        this.name = name;
        this.cvv = cvv;
        this.cardNumber = cardNumber;
        this.expiry = expiry;
    }


    @Override
    public void pay(int amount) {
        System.out.println(amount +" paid with credit/debit card");
    }
}
