package com.javapatterns.StrategyPattern;

public class Item {

    private String upccode;

    private int price;


    public Item(String upccode, int price) {
        this.upccode = upccode;
        this.price = price;
    }

    public String getUpccode() {
        return upccode;
    }

    public int getPrice() {
        return price;
    }
}
