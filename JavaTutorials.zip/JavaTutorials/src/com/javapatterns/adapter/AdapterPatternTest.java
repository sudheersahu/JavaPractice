package com.javapatterns.adapter;

public class AdapterPatternTest {

    public static void main(String[] args){
     testClassAdapter();
     testObjectAdapter();

    }

    public static void testClassAdapter(){
          SocketClassAdapterImpl  impl =new SocketClassAdapterImpl();
            Volt v3=     getVolt(impl,3);
           Volt v12=    getVolt(impl,12);
           Volt v120=     getVolt(impl,120);

           System.out.println("v3 volts using Class Adapter="+v3.getVolts());
         System.out.println("v12 volts using Class Adapter="+v12.getVolts());
         System.out.println("v120 volts using Class Adapter="+v120.getVolts());

    }

    public static void testObjectAdapter(){
        SocketObjAdapterImpl  impl =new SocketObjAdapterImpl();
        Volt v3=     getVolt(impl,3);
        Volt v12=    getVolt(impl,12);
        Volt v120=     getVolt(impl,120);

        System.out.println("v3 volts using Obj Adapter="+v3.getVolts());
        System.out.println("v12 volts using Obj Adapter="+v12.getVolts());
        System.out.println("v120 volts using Obj Adapter="+v120.getVolts());
    }
    public static Volt getVolt(SocketAdapter adapter, int i) {
        switch (i) {

            case 3: return adapter.get3Volt();
            case 12 : return adapter.get12Volt();
            case  120 : return adapter.get120Volt();
            default: return adapter.get120Volt();
        }
    }
}
