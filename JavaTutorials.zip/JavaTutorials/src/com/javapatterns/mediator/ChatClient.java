package com.javapatterns.mediator;

public class ChatClient {

    public static void main(String[] args){
        ChatMediator mediator = new ChatImpl();
        User user = new UserImpl(mediator,"John");
        User user1 = new UserImpl(mediator,"Sam");
        User user2 = new UserImpl(mediator, "David");
        User user3 = new UserImpl(mediator," Ram");
        mediator.addUser(user);
        mediator.addUser(user1);
        mediator.addUser(user2);
        mediator.addUser(user3);
        user.send("Hi All");
    }
}
