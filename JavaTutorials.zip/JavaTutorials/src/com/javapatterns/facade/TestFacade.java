package com.javapatterns.facade;
import com.javapatterns.facade.HelperFacade;

public class TestFacade {

   public  static void main(String[] args){
       String tableName="Employee";

       HelperFacade.getReport(HelperFacade.DBTypes.MYSQL, HelperFacade.ReportTypes.HTML, tableName);
       HelperFacade.getReport(HelperFacade.DBTypes.ORACLE, HelperFacade.ReportTypes.PDF, tableName);
   }
}
