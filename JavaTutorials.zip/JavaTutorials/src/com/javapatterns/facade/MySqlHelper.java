package com.javapatterns.facade;

import java.sql.Connection;

public class MySqlHelper {

    public static Connection getSQLConnection(){
        return null;
    }

    public void getPDFSqlReport(String tableName, Connection con){

    }

    public void getHTMLSqlReport(String tableName, Connection con){

    }
}
