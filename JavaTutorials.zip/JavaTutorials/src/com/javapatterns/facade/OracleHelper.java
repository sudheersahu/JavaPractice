package com.javapatterns.facade;

import java.sql.Connection;

public class OracleHelper {

    public static Connection getOracleConnection(){
        return null;
    }

    public void getPDFOracleReport(String tableName, Connection con){

    }

    public void getHTMLOracleReport(String tableName, Connection con){

    }
}
