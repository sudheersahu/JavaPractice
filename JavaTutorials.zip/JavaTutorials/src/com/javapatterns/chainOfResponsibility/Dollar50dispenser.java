package com.javapatterns.chainOfResponsibility;

public class Dollar50dispenser implements  DispenseChain {
    public Dollar50dispenser() {
        super();
    }

    private DispenseChain chain;

    @Override
    public void setNextChain(DispenseChain chain) {
        this.chain = chain;
    }

    @Override
    public void dispense(Currency curr) {
        if(curr.getMoney() >= 50 ){
            int num = curr.getMoney()/50;
            int rem =curr.getMoney()%50;
            System.out.println("Dispensing "+num+" 50$ note");
            if(rem!=0){
                this.chain.dispense(new Currency(rem));
            }
        }else{
            this.chain.dispense(curr);
        }
    }
}
