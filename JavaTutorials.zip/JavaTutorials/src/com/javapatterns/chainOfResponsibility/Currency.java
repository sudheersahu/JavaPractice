package com.javapatterns.chainOfResponsibility;

public class Currency {
    public int money;

    public Currency(int money) {
        this.money = money;
    }


    public int getMoney() {
        return money;
    }
}
