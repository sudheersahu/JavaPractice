package com.javapatterns.chainOfResponsibility;

public interface DispenseChain {

    void setNextChain(DispenseChain chain);

    void dispense(Currency curr);
}
