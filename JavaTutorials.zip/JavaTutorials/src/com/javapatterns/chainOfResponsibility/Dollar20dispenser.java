package com.javapatterns.chainOfResponsibility;

public class Dollar20dispenser implements  DispenseChain {
    private DispenseChain chain;

    @Override
    public void setNextChain(DispenseChain chain) {
        this.chain = chain;
    }

    @Override
    public void dispense(Currency curr) {
        if(curr.getMoney() >= 20 ){
            int num = curr.getMoney()/20;
            int rem =curr.getMoney()%20;
            System.out.println("Dispensing "+num+" 20$ note");
            if(rem!=0){
                this.chain.dispense(new Currency(rem));
            }
        }else{
            this.chain.dispense(curr);
        }
    }
}
