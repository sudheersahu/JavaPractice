package com.javapatterns.chainOfResponsibility;

import java.util.Scanner;

public class ATMDispenseChain {

    DispenseChain chain;


    public ATMDispenseChain() {
        this.chain = new Dollar50dispenser();
        DispenseChain c2 = new Dollar20dispenser();
        DispenseChain c3 = new Dollar10dispenser();

        // set the chain of responsibility
        chain.setNextChain(c2);
        c2.setNextChain(c3);
    }

    public static void main(String[] args){
        ATMDispenseChain atmDispenser = new ATMDispenseChain();
        while(true){
            int amount = 0;
            System.out.println("Enter amount to dispense");
            Scanner sc = new Scanner(System.in);
            amount = sc.nextInt();
            if (amount % 10 != 0) {
                System.out.println("Amount should be in multiple of 10s.");
                return;
            }
            // process the request
            atmDispenser.chain.dispense(new Currency(amount));
        }

    }
}
