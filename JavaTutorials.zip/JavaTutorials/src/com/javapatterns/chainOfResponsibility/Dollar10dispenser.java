package com.javapatterns.chainOfResponsibility;

public class Dollar10dispenser implements  DispenseChain {

    private DispenseChain chain;
    @Override
    public void setNextChain(DispenseChain chain) {
     this.chain = chain;
    }

    @Override
    public void dispense(Currency curr) {
        if(curr.getMoney() >= 10 ){
            int num = curr.getMoney()/10;
            int rem =curr.getMoney()%10;
            System.out.println("Dispensing "+num+" 10$ note");
            if(rem!=0){
               this.chain.dispense(new Currency(rem));
            }
        }else{
            this.chain.dispense(curr);
        }

    }
}
