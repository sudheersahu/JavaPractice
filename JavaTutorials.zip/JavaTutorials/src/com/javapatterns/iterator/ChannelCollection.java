package com.javapatterns.iterator;

public interface ChannelCollection {

    public void addCollection(Channel channel);

    public void removeCollection(Channel channel);

    public ChannelIterator iterator(ChannelTypeEnum  typeEnum);
}
