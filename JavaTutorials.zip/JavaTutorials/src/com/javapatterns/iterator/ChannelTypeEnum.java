package com.javapatterns.iterator;

public enum ChannelTypeEnum {

    ENGLISH, HINDI, FRENCH, ALL;
}
