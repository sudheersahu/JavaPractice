package com.javapatterns.iterator;

public interface ChannelIterator {

    boolean hasNext();

    Channel next();
}
