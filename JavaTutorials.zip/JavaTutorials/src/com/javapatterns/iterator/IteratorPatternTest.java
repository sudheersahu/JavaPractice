package com.javapatterns.iterator;

public class IteratorPatternTest {

    public static void main(String[] args){
        ChannelCollection collection = populateChannels();
        ChannelIterator baseIterator = collection.iterator(ChannelTypeEnum.ALL) ;
        while(baseIterator.hasNext()){
            Channel c = baseIterator.next();
            System.out.println(c.toString());
        }

        System.out.println("******");
        ChannelIterator  englishIterator = collection.iterator(ChannelTypeEnum.ENGLISH);
        while (englishIterator.hasNext()){
            Channel c = englishIterator.next();
            System.out.println(c.toString());
        }

    }

    private static ChannelCollection populateChannels(){
        ChannelCollection channels = new ChannelCollectionImpl();
        channels.addCollection(new Channel(102.4 , ChannelTypeEnum.ENGLISH));
        channels.addCollection(new Channel(98.4 , ChannelTypeEnum.HINDI));
        channels.addCollection(new Channel(99.4 , ChannelTypeEnum.FRENCH));
        channels.addCollection(new Channel(107.4 , ChannelTypeEnum.ENGLISH));
        channels.addCollection(new Channel(96.4 , ChannelTypeEnum.HINDI));
        channels.addCollection(new Channel(97.4 , ChannelTypeEnum.FRENCH));
        return channels;
    }
}
