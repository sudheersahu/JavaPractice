package com.javapatterns.factory;

public class ServerFactory implements ComputerAbstractFatory {

    private String hdd;
    private String ram;
    private String cpu;

    public ServerFactory(String hdd, String ram, String cpu) {
        this.hdd = hdd;
        this.ram = ram;
        this.cpu = cpu;
    }

    @Override
    public Computer createComputer() {
        return new Server(hdd,ram,cpu);
    }
}
