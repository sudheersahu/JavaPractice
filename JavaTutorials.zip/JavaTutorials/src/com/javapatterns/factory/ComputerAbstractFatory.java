package com.javapatterns.factory;

public interface ComputerAbstractFatory {
    public Computer createComputer();
}
