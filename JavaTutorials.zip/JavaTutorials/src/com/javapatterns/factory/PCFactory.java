package com.javapatterns.factory;

public class PCFactory implements  ComputerAbstractFatory {

    private String hdd;
    private String ram;
    private String cpu;

    public PCFactory(String hdd, String ram, String cpu) {
        this.hdd = hdd;
        this.ram = ram;
        this.cpu = cpu;
    }

    @Override
    public Computer createComputer() {
        return  new PC(hdd,ram,cpu);
    }
}
