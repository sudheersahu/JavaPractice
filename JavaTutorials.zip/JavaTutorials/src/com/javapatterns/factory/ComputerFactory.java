package com.javapatterns.factory;

public class ComputerFactory {

  /*  public static Computer getComputer(String type,String ram, String cpu, String hdd) {
        if ("PC".equalsIgnoreCase(type))
            return new PC(hdd, ram, cpu);
        else if ("Server".equalsIgnoreCase(type))
            return new Server(hdd, ram, cpu);

        return null;
    }*/

  public static Computer getComputer(ComputerAbstractFatory factory){
     return factory.createComputer();
  }
}
