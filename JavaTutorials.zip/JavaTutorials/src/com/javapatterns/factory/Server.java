package com.javapatterns.factory;

public class Server extends Computer {
    private String hdd;
    private String ram;
    private String cpu;

    public Server(String hdd, String ram, String cpu) {
        this.hdd = hdd;
        this.ram = ram;
        this.cpu = cpu;
    }

    @Override
    public String getHDD() {
        return this.hdd;
    }

    @Override
    public String getRAM() {
        return this.ram;
    }

    @Override
    public String getCPU() {
        return this.cpu;
    }
}
