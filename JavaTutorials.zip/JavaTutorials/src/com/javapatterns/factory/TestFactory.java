package com.javapatterns.factory;

public class TestFactory {

    public static void main(String[] args){
       /* Computer  pc = ComputerFactory.getComputer("PC", "2GB", "I3","500GB");
        Computer server = ComputerFactory.getComputer("Server","8GB", "I7", "1TB");*/

       Computer pc = com.javapatterns.factory.ComputerFactory.getComputer( new PCFactory("500GB","2GB","I3"));
       Computer server =com.javapatterns.factory.ComputerFactory.getComputer(new ServerFactory("1TB","8GB","i7"));

        System.out.println("Factory PC Config "+pc );
        System.out.println("Factory Server Config "+server );
    }
}
