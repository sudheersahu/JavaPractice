package com.javapatterns.factory;

public class PC extends Computer
{
    public PC(String hdd, String ram, String cpu) {
        this.hdd = hdd;
        this.ram = ram;
        this.cpu = cpu;
    }

    @Override
    public String getHDD() {
        return this.hdd;
    }

    @Override
    public String getRAM() {
        return this.ram;
    }

    @Override
    public String getCPU() {
        return this.cpu;
    }

    private String hdd;
    private String ram;
    private String cpu;


}
