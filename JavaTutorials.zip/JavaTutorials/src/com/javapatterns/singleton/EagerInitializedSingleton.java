package com.javapatterns.singleton;

public class EagerInitializedSingleton {
    private EagerInitializedSingleton() {
    }

    private static  final EagerInitializedSingleton instance = new EagerInitializedSingleton();

    private static EagerInitializedSingleton getInstance(){
        return instance;
    }
}
