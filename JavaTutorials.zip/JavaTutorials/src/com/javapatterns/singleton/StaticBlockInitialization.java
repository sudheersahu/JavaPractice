package com.javapatterns.singleton;

public class StaticBlockInitialization {
    private StaticBlockInitialization() {
    }

    private static StaticBlockInitialization instance;

    static{
        try{
            instance = new StaticBlockInitialization();
        }catch(Exception e){
            throw new RuntimeException("Exception occured in creating singleton instance");
        }

    }

    private static StaticBlockInitialization getInstance(){
        return instance;
    }
}
