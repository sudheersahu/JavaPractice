package com.javapatterns.singleton;

public class LazyInitilization {
    private LazyInitilization() {
    }

    private static LazyInitilization instance;

    private static LazyInitilization getInstance(){
        if(instance == null){
            instance = new LazyInitilization();
        }
        return instance;
    }
}
