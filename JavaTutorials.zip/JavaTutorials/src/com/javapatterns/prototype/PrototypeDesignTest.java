package com.javapatterns.prototype;

import java.util.List;

public class PrototypeDesignTest {

    public static void main(String[] args) throws CloneNotSupportedException{
        Employees emps = new Employees();
        emps.loadData();
        Employees empsNew = (Employees)emps.clone();
        Employees empsNew1 = (Employees)emps.clone();

        List<String> empsNewList = empsNew.getEmpList();
        empsNewList.add("John");
        List<String>  empsNewList1 = empsNew1.getEmpList();
        empsNewList1.remove("Pankaj");

       System.out.println("Emp list "+ emps.getEmpList());
        System.out.println("Emp list new "+ empsNew.getEmpList());
        System.out.println("Emp list new 1 "+ empsNew1.getEmpList());

    }
}
