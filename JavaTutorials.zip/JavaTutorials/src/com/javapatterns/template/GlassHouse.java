package com.javapatterns.template;

public class GlassHouse extends  HouseTemplate {
    @Override
    public void buildPillars() {
        System.out.println("Build Glass Pillars");
    }

    @Override
    public void buildWalls() {
        System.out.println("Build Glass walls");
    }

    @Override
    public void buildFoundation() {
        super.buildFoundation();
    }

    @Override
    public void buildWindows() {
        super.buildWindows();
    }
}
