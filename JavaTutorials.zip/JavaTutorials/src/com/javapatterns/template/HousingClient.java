package com.javapatterns.template;

public class HousingClient {

    public static void main(String[] args){
        HouseTemplate template = new GlassHouse();
        template.buildHouse();
        System.out.println("************");
        HouseTemplate template2 = new WoodenHouse();
        template2.buildHouse();
    }
}
