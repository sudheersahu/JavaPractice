package com.javapatterns.template;

public class WoodenHouse extends HouseTemplate {
    @Override
    public void buildPillars() {
      System.out.println("Build Wooden House");
    }

    @Override
    public void buildWalls() {
        System.out.println("Build Wooden Walls");
    }

    @Override
    public void buildFoundation() {
        super.buildFoundation();
    }

    @Override
    public void buildWindows() {
        super.buildWindows();
    }
}
