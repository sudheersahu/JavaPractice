package com.javapatterns.builder;

public class TestBuilderPattern {

    public static void main(String[] args){
        Computer comp =new Computer.ComputerBuilder("500gb","2gb").setBluetoothEnabled(true).setGraphicsCardEnabled(true).build();
        System.out.println("computer builder "+comp);
    }
}
