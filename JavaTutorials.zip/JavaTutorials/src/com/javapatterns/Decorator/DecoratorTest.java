package com.javapatterns.Decorator;

public class DecoratorTest {

    public static void main(String[] args){
        Car sportsCar = new SportsCar(new BasicCar());
        sportsCar.assemble();

        Car sportsLuxyCar = new SportsCar(new LuxuryCar(new BasicCar()));
        sportsLuxyCar.assemble();
    }
}
