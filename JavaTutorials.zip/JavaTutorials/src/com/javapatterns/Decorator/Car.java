package com.javapatterns.Decorator;

public interface Car {

    public void assemble();
}
