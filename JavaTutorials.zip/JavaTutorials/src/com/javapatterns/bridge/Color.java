package com.javapatterns.bridge;

public interface Color {

    public void applyColor();
}
