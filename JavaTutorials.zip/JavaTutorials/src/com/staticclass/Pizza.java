package com.staticclass;

public class Pizza {

    private static String cookedCount;
    private boolean isThinCrust;

    static class PizzaSales{

        private static String orderedCount;
        public static String deliveredCount;


        public PizzaSales() {
            System.out.println("Static field of enclosing class is "
                    + Pizza.cookedCount);
            System.out.println("Non-static field of enclosing class is "
                    + new Pizza().isThinCrust);
        }


    }

    Pizza(){
        System.out.println("Non private Static field of static class is "
                + PizzaSales.deliveredCount);
        System.out.println(" private static  field of static class is "
                + PizzaSales.orderedCount);
    }

    public static void main(String[] args){
        new Pizza.PizzaSales();
    }
}
