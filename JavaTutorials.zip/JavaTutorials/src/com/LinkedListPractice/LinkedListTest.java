package com.LinkedListPractice;

public class LinkedListTest {

    public static void main(String args[]){

    }
}
