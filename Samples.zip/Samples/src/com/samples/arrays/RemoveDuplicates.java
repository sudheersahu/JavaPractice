package com.samples.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;

public class RemoveDuplicates {
	 public static void main(String args[]){
	        int[][] test = new int[][]{
	                {1, 1, 2, 2, 3, 4, 5},
	                {1, 1, 1, 1, 1, 1, 1},
	                {1, 2, 3, 4, 5, 6, 7},
	                {1, 2, 1, 1, 1, 1, 1},};

	        for(int[] input : test ){
	            System.out.println("Array with Duplicates       : " + Arrays.toString(input));
	            System.out.println("After removing duplicates   : " + Arrays.toString(removeDuplicates(input)));
	        }
	        sumofMultiplesOfThreeorFive(10);
	        System.out.println("sumofMultiplesOfThreeorFive " +sumofMultiplesOfThreeorFive(10));
	        fibannoci();
	        numOfSun();
	        
	        Integer five= new Integer(55);
	        Long nine = new Long(99);
	        Double doubl = new Double(33.22);
	        int i=1;
	        System.out.println("total" +five+nine+i+doubl);
	        
	        int[] array1 = {9,3,9,3,9,7,9};
	        int odd =  oddOccurenceInArray(array1);
	         System.out.println(odd);
	    }

	    public static int[] removeDuplicates(int[] input) {

	        Arrays.sort(input);
	        int[] result = new int[input.length];
	        int previous = input[0];
	        result[0] = previous;

	        for (int i = 1; i < input.length; i++) {
	            if (previous != input[i]) {
	                result[i] = input[i];
	            }

	            previous = input[i];
	        }
	        return result;
	    }
	    
	    static int oddOccurenceInArray(int[] arr){
	        HashMap<Integer,Integer> hp =new HashMap<>();

	        for(int i =0; i< arr.length;i++){
	            if(hp.containsKey(arr[i]) && hp.get(arr[i]) == 1){
	                hp.remove(arr[i]);
	            }else{
	                hp.put(arr[i],1);
	            }
	        }

	        for(int key : hp.keySet()){
	            return key;
	        }
	       return 0;
	    }
	    
	    public static int sumofMultiplesOfThreeorFive(int n) {
	    	
	    	int sum =0 ;
	    	
	    	for(int i =0; i<n ; i++) {
	    		
	    		if(i%3 == 0 || i%5 == 0) {
	    			sum+= i;
	    		}
	    	}
			return sum;
	    	
	    }
	    
	    public static void fibannoci() {
	    	
	    	int a=0; int b=1;
	    	int c=0;
	    	int i;
	    	int n = 10;
	    	int sum = 0;
	    	 System.out.println(" " + a + " "+b);
	    	  for( i=1; i<=n; i++) {
	    		  c= a+b;
	    		  System.out.println(" " + c);
	    		  if(c%2==0) {
	    			  sum+= c; 
	    		  }
	    		  
	              a=b;
	              b=c;
	    	  }

	    	  System.out.println("sum "+sum);
	    }
	    
	    public static void numOfSun() {
	    	
	    	 int counter = 0;
	         Calendar c = Calendar.getInstance();
	         int Day_Of_Month=1; //This makes it easier in case you want to tweak the test, to say, 

	         for (int year = 1901; year<=2000; year++){
	             for (int month = 0; month <12; month++){
	                 c.set(year, month, 1);
	                 int day_of_week = c.get(Calendar.DAY_OF_WEEK);
	                 if(day_of_week==1){
	                     counter++;
	                 }
	             }
	         }
	         System.out.println(counter);
	    	 
	    	
	    }
	    
	  
	    
	  
}
